import React from 'react';

const NavBar = (props) => {
  return (
    <>
      <p>Navbar here</p>
    </>
  );
};

export default NavBar;
