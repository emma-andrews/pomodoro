const welcomePage = '/';

const settingsPage = '/settings';

const accountPage = '/account';

const homePage = '/home';

const paths = {
  welcomePage,
  settingsPage,
  accountPage,
  homePage,
};

export default paths;
