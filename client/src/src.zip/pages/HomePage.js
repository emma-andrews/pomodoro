import React from 'react';

const HomePage = (props) => {
  return (
    <>
      <p>home page here</p>
    </>
  );
};

export default HomePage;
