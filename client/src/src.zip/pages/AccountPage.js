import React from 'react';

const AccountPage = (props) => {
  return (
    <>
      <p>account page here</p>
    </>
  );
};

export default AccountPage;
