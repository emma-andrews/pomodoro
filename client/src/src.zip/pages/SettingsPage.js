import React from 'react';

const SettingsPage = (props) => {
  return (
    <>
      <p>settings page here</p>
    </>
  );
};

export default SettingsPage;
