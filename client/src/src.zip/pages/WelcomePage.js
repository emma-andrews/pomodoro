import React from 'react';
import { Button } from 'react-bootstrap';
import { useHistory } from 'react-router-dom';

import axios from 'axios';

const WelcomePage = (props) => {
  const history = useHistory();

  return (
    <>
      <Button href='/internal/spotify_auth'>Stuff!</Button>
      <p>welcome page here</p>
    </>
  );
};

export default WelcomePage;
